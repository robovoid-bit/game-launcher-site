$content = [System.IO.File]::ReadAllText("C:\Users\blair\Downloads\classroom 6x\index.html")
Write-Host "File size: $($content.Length) chars"

# Count href patterns
$m1 = [regex]::Matches($content, 'href="(/view/classroom6x/[^"?]+)\?authuser=0"')
Write-Host "Internal /view/ links: $($m1.Count)"

$m2 = [regex]::Matches($content, 'href="(https://www\.google\.com/url\?q=[^"]+)"')
Write-Host "External google redirect links: $($m2.Count)"

# Show first few internal
Write-Host "`nFirst 5 internal:"
for($i=0; $i -lt [Math]::Min(5,$m1.Count); $i++) {
    Write-Host $m1[$i].Groups[1].Value
}

Write-Host "`nFirst 5 external:"
for($i=0; $i -lt [Math]::Min(5,$m2.Count); $i++) {
    Write-Host $m2[$i].Groups[1].Value.Substring(0, [Math]::Min(100, $m2[$i].Groups[1].Value.Length))
}
